import RubiksCube from './components/RubiksCube'

function App() {
  return (
    <div className="w-full h-screen">
      <RubiksCube />
    </div>
  )
}

export default App